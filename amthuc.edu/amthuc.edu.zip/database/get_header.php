<?php
class Get_header extends Database
{
	protected $_url;
	
	public function __construct()
	{
		$this->connect();
	}
	public function setUrl($url)
	{
		$this->_url=$url;
	}
	public function getUrl()
	{
		return $this->_url;
	}	
	public function get_header()
	{
		$sql="select title,description,tags from category_vi where url='".$this->_url."'";
		$this->query($sql);
		$data="";
		while($row=$this->fetch())
			$data[]=$row;
		return $data;
	}
}