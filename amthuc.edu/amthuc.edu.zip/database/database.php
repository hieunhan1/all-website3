<?php
class Database
{
    protected $_host="localhost";
	protected $_userhost="root";
    protected $_passhost="";
    protected $_dbname="netspace_edu"; 
	/*
	protected $_userhost 		= 	"dayamthu_quyenq";
	protected $_passhost 		= 	"binhthuong00";
	protected $_dbname			=	"dayamthu_test";
	*/
    protected $_conn;
    protected $_result;
	private $magic_quotes_active; 
    private $real_escape_string_exists;
	
	public function connect()
    {
        $this->_conn=mysql_connect($this->_host,$this->_userhost,$this->_passhost) or die("can not connect server");
        mysql_select_db($this->_dbname,$this->_conn) or die("can not find database");
        mysql_set_charset('utf8',$this->_conn);
    }
    public function disconnect()
    {
        if(!is_null($this->_conn))
        {
            mysql_close($this->_conn);
        }
    }
	 public function query($sql)
    {
        $this->_result=mysql_query($sql);
        
    }
    public function num_rows()
    {
        if(!is_null($this->_result))
        {
            $row=mysql_num_rows($this->_result);
        }
        else
            $row=false;
        return $row;
    }
    public function fetch()
    {
        if(!is_null($this->_result))
        {
            $row=mysql_fetch_assoc($this->_result);
        }
        else
            $row=False;
        return $row;
    }	
	function encry_pass($pass,$salt = '!@#$%^&*()')
	{
		return md5(md5($pass.$salt));
	}
	public function sqlQuote( $value ){ 
        //Kiểm tra xem version PHP bạn sử dụng có hiểu hàm mysql_real_escape_string() hay ko 
         
        if ($this->real_escape_string_exists) { 
            //Trường hợp sử dụng PHP v4.3.0 trở lên 
            //PHP hiểu hàm mysql_real_escape_string() 
             
            if( $this->magic_quotes_active ) {  
                //Trong trường hợp PHP đã hỗ trợ hàm get_magic_quotes_gpc() 
                //Ta sử dụng hàm stripslashes để bỏ qua các dấu slashes 
                $value = stripslashes( $value );  
            } 
            $value = mysql_real_escape_string( $value ); 
        }  
        else { 
            //Trường hợp dùng cho các version PHP dưới 4.3.0 
            //PHP không hiểu hàm mysql_real_escape_string() 
             
            if( !$this->magic_quotes_active ){  
                //Trong trường hợp PHP không hỗ trợ hàm get_magic_quotes_gpc() 
                //Ta sử dụng hàm addslashes để thêm các dấu slashes vào giá trị 
                $value = addslashes( $value );  
            } 
            // Nếu hàm get_magic_quotes_gpc() đã active có nghĩa là các dấu slashes đã tồn tại rồi 
        } 
        return $value; 
    }
}