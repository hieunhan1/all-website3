<?php
include_once("database.php");
$db=new Database;
$db->connect();

include_once("get_header.php");
$get_header=new Get_header;