<?php
include_once("database/clude_database.php");
if(isset($_COOKIE['language']))
{
	if($_COOKIE['language']=="en")
	{
		include("language/en.php");
	}
	else
	{
		include("language/vi.php");
	}
}
else
{
	$_COOKIE['language']="vi";
	include("language/vi.php");
}

$get_header->setUrl('trang-chu.html');
$header=$get_header->get_header();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?=$header[0]['title']?></title>
    <meta name="title" content="<?=$header[0]['title']?>" />
    <meta name="description" content="<?=$header[0]['description']?>" />
    <meta name="keywords" content="<?=$header[0]['tags']?>" />    
    <meta http-equiv="content-language" content ="vi" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta property="og:title" content="Trường dạy nấu ăn - mở quán ăn - học nấu ăn - Học pha chế - Dạy pha chế - Dạy ẩm thực" />
    <meta property="og:description" content="Trường dạy ẩm thực - Trường dạy nấu ăn - Trường học nấu ăn - đào tạo mở quán ăn hàng đầu - Học pha chế - Dạy pha chế" />
    <link href="stylesheet/style_fomat.css" rel="stylesheet" type="text/css" />	  
    <script type="text/javascript" src="js/realshadow.js"></script><!--effect shadow catlogy-->
    <!-- create cufon font-->
    <script type="text/javascript" src="js/cufon-yui.js"></script>
	<script type="text/javascript" src="js/UVNBayBuom_400-UVNBayBuom_400.font.js"></script>
</head>
<body>
	<div class="wr_body">
    	<div class="head">
		<?php			 
			include_once("template/tophead.php");
			if(!isset($_GET["cm"]))
				include_once("template/slider.php");			 
			require_once("template/linkwebsite.php");
			if(!isset($_GET["cm"])) 
				include_once("template/category.php"); 
		?>
        </div>
        <div class="content">
        	<?php
				if(isset($_GET["cm"]))
					$cm=$_GET["cm"];
				else
					$cm="";
				switch ($cm)
				{
					case _DOITAC_LINK:
						include_once('template/partner.php');
						break;
					case _DICHVU_LINK:
						include_once('template/program.php');
						break;	
					case _TINTUC_LINK:
						include_once('template/event.php');
						break;
					case _LIENHE_LINK:
						include_once('template/contact.php');
						break;
					case _EMAIL_LINK:
						include_once('template/email.php');
						break;
					case _CONGTHUCDAYNAUAN_LINK:
						include_once("template/view_category.php");
						break;
					case _CHITIET_LINK:
						include_once("template/view_category.php");
						break;
					case _NGHIENCUUPHATTRIENAMTHUC_LINK:
						include_once("template/view_category.php");
						break;
					case _DAYNAUANONLINE_LINK:
						include_once("template/view_category.php");
						break;
					default:
						include_once("template/content_home.php");
				}				
			?>
        </div>
		<?php
			require_once("template/footer.php");
		?>
    </div>
</body>
</html>