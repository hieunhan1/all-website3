<?php
define("_TRANGCHU_LB","Home");
define("_DOITAC_LB","Partners");
define("_DICHVU_LB","Programs");
define("_TINTUC_LB","News");
define("_LIENHE_LB","Contact");
define("_EMAIL_LB","Email");
define("_FORUM_LB","Forum");
define("_DIACHI_LB","Address");
define("_DIACHI_CT_LB","30 Nguyen Huy Tu Street, Ward Dakao, District 1, Ho Chi Minh City, Vietnam");
define("_DIACHI_NOTE_LB","(near Dakao market)");
define("_DIENTHOAI_LB","Tel"); 
define("_DIENTHOAI_CT_LB","(+84-8) 6291 2698 - (+84-8) 6291 0908");
define("_EMAIL_CT_LB","info@dayamthuc.vn");
define("_CONGTHUCNAUAN_LB","Food Recipes");
define('_DAYAMTHUC_LB','Culinary Training');
define('_DAYAMTHUC_CT_LB','Professional training<br />in kitchen and bar');
define('_COOKINGCLASS_LB','cooking class');
define('_COOKINGCLASS_CT_LB','bringing Vietnamese cuisine to the world');
define('_TUVANSETUPNHAHANGKHACHSAN_LB','Hospitality <br /> Outlet Services');
define('_TUVANSETUPNHAHANGKHACHSAN_CT_LB','Professional - High Expert');
define('_NGHIENCUUPHATTRIENAMTHUC_LB','Culinary Research and Development');
define('_DAYNAUANONLINE_LB','Online Training');
define('_CHITIET_LB','More details...');
define('_NHAPTUKHOA_LB','Type keywords...');
define('_TIMKIEM_LB','Search');
define('_KHAMPHAMONNGON_LB','Discover new dishes');
define('_MONANDEP_LB','Food Presentations');
define('_XEMCLIP_LB','Watch Clip');
define('_YEUTHICH_LB','Like');
define('_GHIBINHTLUANODAY_LB','Write your comments...');
define('_GUIBINHLUAN_LB','Post Comment');
define('_CACMONLIENQUAN_LB','Related Dishes');
define('_CACHCHEBIEN_LB','Cooking Method');
define('_ABOUTNETSPACE_LB','about netspace');
define('_HOATDONG_LB','Activities');
define('_THUCUONGDEP_LB','Beverages');
define('_GIOITHIEUNETSPACE_LB','About NetSpace');
define('_GIOITHIEUNETSPACE_CT_LB','
<li>Founded in 2010, NetSpace Institute aims at reaching our vision as “Human Resource Power”, desiring to converge the strength of all human resources that are passionate and empowered with culinary training based on hamornizing the muatual contributions and benefits of national professional culinary training and education. Embeded the vocational training orientation that benchmarks with international training standards, we operate on functional criterion as bridging training with society and business:
</li>
<li>
  <ul>
	  <li><img src="images/iconlist.png" alt="" />NetSpace School is to supply the human resources that are empowered with skills to contribute to the development of society and businesses.</li>
	  <li><img src="images/iconlist.png" alt="" />NetSpace School’s development goal is aiming to establish the network of partners that incorporates strengths in order to create a collective force in developing professional vocational training and education in Vietnam.</li>
  </ul>
</li>
');
define('_CUOI_LB','Last');
define('_INBAIVIET_LB','Print article');


define("_DOITAC_LINK","Doi-tac");
define("_DICHVU_LINK","Dich-vu");
define("_TINTUC_LINK","Tin-tuc");
define("_LIENHE_LINK","Lien-he");
define("_EMAIL_LINK","Email");
define("_FORUM_LINK","Forum");
define("_CONGTHUCDAYNAUAN_LINK","Cong-thuc-day-nau-an");
define('_NGHIENCUUPHATTRIENAMTHUC_LINK','Nghien-cuu-phat-trien-am-thuc');
define('_CHITIET_LINK','Chi-tiet');

define('_IMGHEADNEW_LINK','images/img_head_new2.png');
define('_IMGHEADPICTURE_LINK','images/img_head_picture2.png');
define('_CONTACTFOOTERTOPLEFT_LINK','background: url("images/contact_footer_top_left2.png") no-repeat scroll 0 0 rgba(0, 0, 0, 0);');
define('_DAYNAUANONLINE_LINK','online-training');
