<?php
define("_TRANGCHU_LB","Trang Chủ");
define("_DOITAC_LB","Đối Tác");
define("_DICHVU_LB","Dịch Vụ");
define("_TINTUC_LB","Tin Tức");
define("_LIENHE_LB","Liên Hệ");
define("_EMAIL_LB","Email");
define("_FORUM_LB","Forum");
define("_DIACHI_LB","Địa chỉ");
define("_DIACHI_CT_LB","30 Nguyễn Huy Tự, Phường ĐaKao, Quận 1, Tp.HCM");
define("_DIACHI_NOTE_LB","(Đối diện Chợ Đakao)");
define("_DIENTHOAI_LB","Điện thoại"); 
define("_DIENTHOAI_CT_LB","(08) 6291 2698 - (08) 6291 0908");
define("_EMAIL_CT_LB","info@dayamthuc.vn");
define("_CONGTHUCNAUAN_LB","Công thức <br /> Nấu Ăn");
define('_DAYAMTHUC_LB','Dạy Ẩm Thực');
define('_DAYAMTHUC_CT_LB','Đào tạo nấu ăn và <br /> pha chế chuyên nghiệp');
define('_COOKINGCLASS_LB','cooking class');
define('_COOKINGCLASS_CT_LB','mang ẩm thực việt nam ra thế giới');
define('_TUVANSETUPNHAHANGKHACHSAN_LB','tư vấn, setup<br />nhà hàng<br />khách sạn');
define('_TUVANSETUPNHAHANGKHACHSAN_CT_LB','Chuyên nghiệp - Đẳng cấp');
define('_NGHIENCUUPHATTRIENAMTHUC_LB','Nghiên cứu & Phát triển ẩm thực');
define('_DAYNAUANONLINE_LB','Dạy nấu ăn Online');
define('_CHITIET_LB','Chi tiết...');
define('_NHAPTUKHOA_LB','Nhập từ khóa ...');
define('_TIMKIEM_LB','Tìm Kiếm');
define('_KHAMPHAMONNGON_LB','khám phá món ngon');
define('_MONANDEP_LB','món ăn đẹp');
define('_XEMCLIP_LB','xem clip');
define('_YEUTHICH_LB','yêu thích');
define('_GHIBINHTLUANODAY_LB','Ghi bình luận của bạn ở đây...');
define('_GUIBINHLUAN_LB','Gửi Bình Luận');
define('_CACMONLIENQUAN_LB','các món liên quan');
define('_CACHCHEBIEN_LB','cách chế biến');
define('_ABOUTNETSPACE_LB','about netspace');
define('_HOATDONG_LB','hoạt động');
define('_THUCUONGDEP_LB','Thức uống đẹp');
define('_GIOITHIEUNETSPACE_LB','Giới Thiệu NETSPACE');
define('_GIOITHIEUNETSPACE_CT_LB','
<li>Được thành lập từ năm 2010, Netspace institute với khẩu hiệu "Human resource power", mong muốn tập hợp tất cả sức mạnh nguồn nhân lực có năng lực và có tâm huyết
với ngành giáo dục trên cơ sở sự kết hợp hài hòa về sự đóng góp và lợi ích vào sự nghiệp giáo dục chung của đất nước. Cùng với một định hướng về giáo dục là dạy nghề theo chuẩn đào tạo quốc tế dựa trên tiêu chí hoạt động đó là kết nối trường học với xã hội, doanh nghiệp:
</li>
<li>
  <ul>
	  <li><img src="images/iconlist.png" alt="" />Netspace School là trường học, cung ứng  cho xã hội, các doanh nghiệp những con người có khả năng làm việc tốt giúp xã hội, doanh nghiệp phát triển.</li>

	  <li><img src="images/iconlist.png" alt="" />Netspace School định hướng phát triển nhằm thiết lập nhiều mối quan hệ cùng với các đối tác, kết hợp những điểm mạnh của mỗi đối tác, tạo sức mạnh 
tổng hợp phát triển sự nghiệp giáo dục tại Việt Nam.</li>
  </ul>
</li>
');
define('_CUOI_LB','Cuối');
define('_INBAIVIET_LB','In bài viết');


define("_DOITAC_LINK","Doi-tac");
define("_DICHVU_LINK","Dich-vu");
define("_TINTUC_LINK","Tin-tuc");
define("_LIENHE_LINK","Lien-he");
define("_EMAIL_LINK","Email");
define("_FORUM_LINK","Forum");
define("_CONGTHUCDAYNAUAN_LINK","Cong-thuc-day-nau-an");
define('_NGHIENCUUPHATTRIENAMTHUC_LINK','Nghien-cuu-phat-trien-am-thuc');
define('_CHITIET_LINK','Chi-tiet');

define('_IMGHEADNEW_LINK','images/img_head_new.png');
define('_IMGHEADPICTURE_LINK','images/img_head_picture.png');
define('_CONTACTFOOTERTOPLEFT_LINK','background: url("images/contact_footer_top_left.png") no-repeat scroll 0 0 rgba(0, 0, 0, 0);');
define('_DAYNAUANONLINE_LINK','day-nau-an-online');
