<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Trường dạy nấu ăn - mở quán ăn - học nấu ăn - Học pha chế - Dạy pha chế - Dạy ẩm thực</title>
<style>
* {
    margin: 0;
    padding: 0;
}
body {
    background:url(images/bgr_intro.jpg);
}
.tap {
    height: 20px;
    text-align: right;
	padding-right:45px;
}
.tap a {
    color: #FFFFFF;
    font-weight: bold;
    margin-right: 10px;
    text-decoration: none;
}
.info {
    color: #FF0000;
}
.ente:hover {
    color: #FF0000;
}
</style>
</head>
<body onload="time()">
	<script language=javascript>
        var i=11;// la số thời gian tối đa. ở đây mình cho nó chạy từ 1 tới 100
        function time()
        {
            if(i>=0)
            {
                document.getElementById("note").innerHTML="Sau "+i+"s tự động chuyển đến Trang Chủ ";
                i--;
                setTimeout("time()",1000);
            }
            else
            {
				window.location="http://localhost/amthuc.edu/home.php?language=vi";
            }
        } 
    </script>
    <center>
        <table  height=100% align=center>            
            <tr>
                <td valign=center align=center style="vertical-align:middle">        
                    <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"                    
                        codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0"
                        width="1000" height="500" id="test" align="middle">                    
                        <param name="movie" value="intro 4.swf" />                    
                        <param name="quality" value="high" />                    
                        <param name="play" value="true" />                    
                        <param name="bgColor" value="#FFFFFF" />                    
                        <param name="wmode" value="transparent" />                    
                        <embed src="intro 4.swf"                    
                            width="1000" height="500"                    
                            quality="high"                    
                            play="true"                    
                            bgColor="#FFFFFF"                    
                            wmode="transparent"                    
                            type="application/x-shockwave-flash"                    
                            pluginspage="http://www.macromedia.com/go/getflashplayer" />
                    </object>
                </td>
                <tr>
                <td class="tap">
                	<div class="textmarquee">
                        <!--<marquee style="float:left" scrollamount="5" align="right" direction="left" height="100" scrollamount="2" width="65%"><span class="info">Cơ sở dạy nghề ẩm thực NETSPACE - Địa chỉ: 30 Nguyễn Huy Tự, Phường ĐaKao, Quận 1, Tp.HCM</span></marquee> -->                
                    </div>                
                    <div>
                    	<a href="javascript:void(0)" id="note"></a>
                        <a href="javascript:void(0)">|</a>                
                        <a href="http://localhost/amthuc.edu/home.php?language=vi" class="ente"> Vào Trang Chủ</a>                
                    </div>
                </td>
            </tr>
            </tr>
        </table>
    </center>
</body>
</html>

