<?php
	if(isset($_GET['cm']))
	{
	}
?>
<div class="wr_content">
    <div class="top_content">
        <h1>
			<?php 
				if($_GET['cm']==_CONGTHUCDAYNAUAN_LINK)
					echo _CONGTHUCNAUAN_LB;
				else if($_GET['cm']==_CHITIET_LINK)
					echo  _CONGTHUCNAUAN_LB;
				else if($_GET['cm']==_NGHIENCUUPHATTRIENAMTHUC_LINK)
					echo  _NGHIENCUUPHATTRIENAMTHUC_LB;
				else if($_GET['cm']==_DAYNAUANONLINE_LINK)
					echo _DAYNAUANONLINE_LB;
			?>
        </h1>
        <div class="search">
            <input type="text" id="txtsearch" placeholder="<?=_NHAPTUKHOA_LB?>" />
            <input type="button" id="btsearch" value="<?=_TIMKIEM_LB?>" />
        </div>
    </div>
    <div class="more_category">
        <?php
			if($_GET['cm']==_CONGTHUCDAYNAUAN_LINK)
				include('list_category.php');			
			else if($_GET['cm']==_NGHIENCUUPHATTRIENAMTHUC_LINK)
				include('research.php');
			else if($_GET['cm']==_CHITIET_LINK)
				include('view.php');
			else if($_GET['cm']==_DAYNAUANONLINE_LINK)
				include('online_training.php');
        ?>
        <div style="clear:both"></div>
    </div>
    <div style="clear:both"></div>
    
</div>