<div class="footer">
    <div class="top_footer">
        <div class="bot_footer_left" style='<?=_CONTACTFOOTERTOPLEFT_LINK?>'>
            <p>
                <?=_DIACHI_LB?>:<b> <?=_DIACHI_CT_LB?></b><br />
                <?=_DIACHI_NOTE_LB?>
                <br />
                <?=_DIENTHOAI_LB?>:<b><?=_DIENTHOAI_CT_LB?></b>
                <br />
                <?=_EMAIL_LB?>: <b><?=_EMAIL_CT_LB?></b>
            </p>
        </div>
        <div class="bot_footer_right">
            <a href="#">
                <img alt="Youtube" class="icyoutube" title="Youtube" src="images/youtube_2.png" />
            </a>
            <a href="#">
                <img alt="facebook" class="icfacebook" title="Facebook" src="images/facebook.png" />
            </a>
            <a href="#">
                <img alt="google plus" class="icgoogle" title="google plus" src="images/google_plus.png" />
            </a>
        </div>
    </div>
    <div class="partner">
        <script src="js/lib/jquery-1.9.0.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="js/common.js"></script>
        <script type="text/javascript" src="js/jquery.simplyscroll.min.js"></script>
        <script type="text/javascript">
        	(function($){$(function(){$("#scroller").simplyScroll();});})(jQuery);
        </script>
        <div class="simply-scroll-clip">
            <div class="simply-scroll simply-scroll-container">
                <div class="simply-scroll-clip">
                    <ul id="scroller" class="simply-scroll-list" style="width: 2255px;">
                        <li style="list-style:none">
                            <a href="http://fannyicecream.wordpress.com/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/fanny.jpg" alt="Fanny Ice Cream">
                            </a>
                        </li>
                        <li style="list-style:none">
                            <a href="http://www.simplex.com.sg/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/simplex.jpg" alt="Simplex Pte Ltd">
                            </a>
                        </li>
                        <li style="list-style:none">
                            <a href="http://www.vietnamchefs.com/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/hoi-dau-bep-01.jpg" alt="Hội đầu bếp chuyên nghiệp Sài Gòn">
                            </a>
                        </li>
                        <li style="list-style:none">
                            <a href="http://vedan.com.vn/vedan/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/vedan.jpg" alt="Simplex Pte Ltd">
                            </a>
                        </li>    
                        <li style="list-style:none">
                            <a href="http://fannyicecream.wordpress.com/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/fanny.jpg" alt="Fanny Ice Cream">
                            </a>
                        </li>
                        <li style="list-style:none">
                            <a href="http://www.simplex.com.sg/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/simplex.jpg" alt="Simplex Pte Ltd">
                            </a>
                        </li>
                        <li style="list-style:none">
                            <a href="http://www.vietnamchefs.com/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/hoi-dau-bep-01.jpg" alt="Hội đầu bếp chuyên nghiệp Sài Gòn">
                            </a>
                        </li>
                        <li style="list-style:none">
                            <a href="http://vedan.com.vn/vedan/" title="" target="_blank">
                                <img src="http://www.dayamthuc.vn/upload/images/slider_banner/vedan.jpg" alt="Simplex Pte Ltd">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="bot_footer">
        <div class="facebooklike">
            <div id="fb-root"></div> 
        </div>
        <div class="copyright">
            <p>
                Copyright <b>©</b> 2013 by <b>NETSPACE</b>
            </p>
        </div>  
    </div>
</div>