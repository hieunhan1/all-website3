<div class="new">
    <div class="head_new">
        <img alt="tin tức" src="<?=_IMGHEADNEW_LINK?>" />
    </div>
    <div class="list_new">
        <div class="div_new">
            <div class="fram_new">
                <div class="top_fram_new">
                    <div class="img_new">
                        <a href="#">
                            <img alt="" src="upload/truongdaynauan.jpg" />
                        </a>
                    </div>
                    <div class="info_new">
                        <div class="title_new">
                            <a href="#">
                                trường dạy nấu ăn tạo ưu thế riêng cho người học
                            </a>
                        </div>
                        <div class="content_new">
                            <p>
                                Hiên nay, các đơn vị tuyển dụng lao động rất coi trọng việc tuyển
dụng những ứng viên có tay nghề thành thạo. Chính vì vậy, các 
bạn học viên bước ra từ các trường, cơ sở dạy nghề - là những 
nơi tạo điều kiện cho các bạn thường xuyên thực hành đang là 
những ứng viên sáng giá và nhận được sự chào đón của doanh nghiệp.
                            </p>
                        </div>
                    </div>
                 </div>
                 <div class="bottom_fram_new">
                    <div class="num_cmt_new">
                        4 Bình luận
                    </div>
                    <div class="date_new">
                        5-6-2013
                    </div>   
                 </div>
            </div>
        </div>
        <div class="div_new">
            <div class="fram_new">
                <div class="top_fram_new">
                    <div class="img_new">
                        <a href="#">
                            <img alt="" src="upload/truong day nghe am thuc NetSpace 2.jpg" />
                        </a>
                    </div>
                    <div class="info_new">
                        <div class="title_new">
                            <a href="#">
                                Trường dạy nghề ẩm thực NetSpace mở rộng quy mô đào tạo
                            </a>
                        </div>
                        <div class="content_new">
                            <p>
                                Trường dạy nghề ẩm thực NetSpace  từ lâu đã tạo được uy tín trong việc đào tạo nghề bếp. Với mong muốn đào tạo ra nguồn nhân lực bếp có chất lượng cao, Trường không ngừng nỗ lực nâng cao chất lượng giảng dạy, cập nhật giáo trình đào tạo để nắm bắt được xu hướng nghề bếp của thế giới. Đây chính là yếu tố gây dựng nên uy tín Trường dạy nghề ẩm thực NetSpace trong những năm qua. 
                            </p>
                        </div>
                    </div>
                 </div>
                 <div class="bottom_fram_new">
                    <div class="num_cmt_new">
                        3 Bình luận
                    </div>
                    <div class="date_new">
                        20-10-2013
                    </div>
                 </div>
            </div>
        </div>
        <div class="div_new">
            <div class="fram_new">
                <div class="top_fram_new">
                    <div class="img_new">
                        <a href="#">
                            <img alt="" src="upload/pho_bo_01.JPG" />
                        </a>
                    </div>
                    <div class="info_new">
                        <div class="title_new">
                            <a href="#">
                                "Phù thủy" nấu phở ngon - Trong 1 giờ
                            </a>
                        </div>
                        <div class="content_new">
                            <p>
                               "Phù thủy" rút ngắn công đoạn nấu phở lắm công phu chính là đầu bếp Nguyễn Quốc Y, hiệu trưởng Trường dạy nghề ẩm thực Netspace (TP.HCM). Nồi áp suất được đầu bếp Y tận dụng triệt để, nhưng nhờ cách tính toán hợp lý, nồi nước dùng vẫn cứ trong vắt, ngọt ngào và thơm lừng hương bò tinh túy.
                            </p>
                        </div>
                    </div>
                 </div>
                 <div class="bottom_fram_new">
                    <div class="num_cmt_new">
                        1 Bình luận
                    </div>
                    <div class="date_new">
                        15-8-2013
                    </div>
                 </div>
            </div>
        </div>
        <div class="div_new">
            <div class="fram_new">
                <div class="top_fram_new">
                    <div class="img_new">
                        <a href="#">
                            <img alt="" src="upload/truong day nghe am thuc netspace 2(1).jpg" />
                        </a>
                    </div>
                    <div class="info_new">
                        <div class="title_new">
                            <a href="#">
                                Giao lưu với Siêu đầu bếp Alain Nghĩa tại Trường dạy nghề ẩm thực NetSpace
                            </a>
                        </div>
                        <div class="content_new">
                            <p>
                                Nhằm tạo cơ hội cho các bạn học viên được tiếp xúc với những tấm gương nghề bếp, để nghe những suy nghĩ những trăn trở của những người thật việc thật cũng như nghe họ chia sẻ những kinh nghiệm thực tế của mình, để học hỏi và  lấy những điều đó làm kinh nghiệm cho bản thân mình,  Trường dạy nghề ẩm thực NetSpace đã tổ chức một buổi giao lưu với Siêu đầu bếp Alain Nghĩa vào ngày 16/10/2013.
                            </p>
                        </div>
                    </div>
                 </div>
                 <div class="bottom_fram_new">
                    <div class="num_cmt_new">
                        12 Bình luận
                    </div>
                    <div class="date_new">
                        10-9-2013
                    </div>
                 </div>
            </div>
        </div>
    </div> 
    <div style="clear:both"></div>
</div>