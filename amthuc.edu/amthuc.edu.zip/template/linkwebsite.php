<div class="linkwebsite">
    <div class="linkleft">	
        <h1 class="realshadow block round cr" rel="r" ><?=_DAYAMTHUC_LB?></h1>
        <p class="realshadow block round cr" rel="r"><?=_DAYAMTHUC_CT_LB?></p>
        <a href="http://dayamthuc.vn" target="_blank">www.dayamthuc.vn</a>
    </div>
    <div class="linkmid">	
        <h1 class="realshadow block round cr" rel="r"><?=_COOKINGCLASS_LB?></h1>
        <p class="realshadow block round cr" rel="r"><?=_COOKINGCLASS_CT_LB?></p>
        <a href="http://www.cookingclass.com.vn" target="_blank">www.cookingclass.com.vn</a>
    </div>
    <div class="linkright">	
        <h1 class="realshadow block round cr" rel="r"><?=_TUVANSETUPNHAHANGKHACHSAN_LB?></h1>
        <p class="realshadow block round cr" rel="r"><?=_TUVANSETUPNHAHANGKHACHSAN_CT_LB?></p>
    </div>
     <script type="text/javascript">
        (function(){
            realshadow(document.getElementsByClassName('realshadow'));				
        })();
    </script>
</div>