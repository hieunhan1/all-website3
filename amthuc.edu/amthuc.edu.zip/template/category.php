<div class="catelogy">
    <div class="cateleft">
        <div class="img_catelogy">
            <img alt="" src="images/img_ctna.png" />
        </div>
        <a href="?language=<?=$_COOKIE['language']?>&cm=<?=_CONGTHUCDAYNAUAN_LINK?>"><?=_CONGTHUCNAUAN_LB?></a>
    </div>
    <div class="catemid">
        <div class="img_catelogy">
            <img alt="" src="images/img_ncptat.png" />
        </div>
        <a href="?language=<?=$_COOKIE['language']?>&cm=<?=_NGHIENCUUPHATTRIENAMTHUC_LINK?>"><?=_NGHIENCUUPHATTRIENAMTHUC_LB?></a>
    </div>
    <div class="cateright">
        <div class="img_catelogy">
            <img alt="" style="margin-top:7px" src="images/img_dnaonline.png" />
        </div>
        <a href="?language=<?=$_COOKIE['language']?>&cm=<?=_DAYNAUANONLINE_LINK?>"><?=_DAYNAUANONLINE_LB?></a>
    </div>
</div>