<div class="picture">
	<div class="head_picture">
   		<img alt="hình ảnh" src="<?=_IMGHEADPICTURE_LINK?>" />
    </div>    
    <div class="list_picture">    
        <div class="div_picture">    
            <div class="img_picture">    
                <a href="#">    
                    <img alt="" src="images/img2.jpg" />    
                </a>    
            </div>    
            <div class="bottom_picture">   
                <a href="#"><?=_ABOUTNETSPACE_LB?></a>    
            </div>    
        </div>    
        <div class="div_picture">    
            <div class="img_picture">    
                <a href="#">    
                    <img alt="" src="images/img3.jpg" />    
                </a>    
            </div>    
            <div class="bottom_picture">    
                <a href="#"><?=_HOATDONG_LB?></a>    
            </div>    
        </div>    
        <div class="div_picture">    
            <div class="img_picture">    
                <a href="#">    
                    <img alt="" src="images/img4.jpg" />    
                </a>    
            </div>    
            <div class="bottom_picture">    
                <a href="#"><?=_KHAMPHAMONNGON_LB?></a>    
            </div>    
        </div>    
        <div class="div_picture">    
            <div class="img_picture">    
                <a href="#">    
                    <img alt="" src="images/img5.jpg" />    
                </a>    
            </div>    
            <div class="bottom_picture">    
                <a href="#"><?=_THUCUONGDEP_LB?></a>    
            </div>    
        </div>    
    </div>
    <div style="clear:both"></div>
</div>