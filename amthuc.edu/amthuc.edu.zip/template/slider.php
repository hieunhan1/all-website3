<div class="slider">
    <img alt="slider" src="images/slider.png" />
</div>