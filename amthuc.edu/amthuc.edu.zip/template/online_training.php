online_training <br />
<?php
echo $_SERVER['HTTP_HOST'];
echo '<br />';
echo $_SERVER['REQUEST_URI'];
?>