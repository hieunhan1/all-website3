
<div class="top_view_new">
    <div class="left_top_view_new">
        <img src="http://cookingclass.com.vn/public/images/articles/banh%20mi%20in%20US%2001.jpg" alt="" />
    </div>
    <div class="right_top_view_new">
        <p class="khampha"><?=_KHAMPHAMONNGON_LB?></p>
        <h1>chả giờ hải sản</h1>
        <p class="desc_khampha">
            chả giò mực là món ăn có vị thơm mặn ngọt, 
cay hòa trộn với nhau, hương vị thơm ngon,
có cách trình bày rất đẹp mắt .
        </p>
        <div class="button_top_view_new">
            <div class="play">
                <img src="images/play.png" alt="play" />
                <p><?=_XEMCLIP_LB?></p>
            </div>
            <div class="btlike">
                <img src="images/like.png" align="like" />
                <p><?=_YEUTHICH_LB?></p>
            </div>
        </div>
    </div>
</div>
<div class="content_view_new">
    <div class="left_content_view_new">
        <div class="cachchebien">
            <?=_CACHCHEBIEN_LB?>
        </div>
        <div class="content_cachchebien">
        </div>
        <div class="cachchebien">
            <?=_CACMONLIENQUAN_LB?>
        </div>
        <div class="content_cachchebien">
        </div>
    </div>
    <div class="right_content_view_new">
        <div class="share_baiviet">
                <div style="float:left; margin: 32px 32px 0px 0px">
                    <a href="javascript:void(0);"><img src="images/print.png" alt="print" title="<?=_INBAIVIET_LB?>" /></a>
                </div>
            <!-- AddThis Button BEGIN -->
                <div class="addthis_toolbox addthis_default_style " style="float:left">
                    
                    <a class="addthis_button_facebook_like fix" fb:like:layout="button_count"></a>
                    <a class="addthis_button_tweet fix"></a>
                    <!--<a class="addthis_button_pinterest_pinit" pi:pinit:layout="horizontal"></a>-->
                    <a class="addthis_counter addthis_pill_style fix"></a>
                    <a class="addthis_button_google_plusone " g:plusone:size="tall"></a>
                </div>
                <script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
                <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-526f0d9d7a15367d"></script>
            <!-- AddThis Button END -->
        </div>
        <div class="content_baiviet">
            <h1>1.Sơ chế</h1>
            <p>
                - Lạng mỏng ức gà, dùng búa đập nhẹ. Thịt ba chỉ cắt que.
                Ướp thịt gà và thịt ba chỉ với 2M nước tỏi, 1/4m tiêu, 
                1M hạt nêm Aji-ngon để thấm 10 phút.<br />

                - Khoai lang, khoai môn cắt thanh cỡ que diêm. Hành lá cắt khúc. 
                Bột năng trộn với ít nước làm hồ dán.<br />

                - Đặt miếng thịt gà lên thớt, xếp khoai lang, khoai môn, thịt và hành lá
                vào cuộn lại. Dùng hồ dán mí.

            </p>
            <h1>2. Thực hiện</h1>
            <p>
            - Đun nóng dầu ăn, lần lượt lăn cuộn gà qua Aji-Quick® Bột chiên gà giòn,sau đó đem chiên chín vàng, vớt ra để ráo dầu.
            </p>
            <h1>3. Cách dùng:</h1>
            <p>
                - Xếp gà cuộn khoai chiên giòn ra dĩa, dùng kèm xà lách, chấm xốt 
mayonnaise "Aji-mayo" pha tương ớt (tỉ lệ 2:1).

            </p>						
        </div>
        
        <div class="comment_baiviet">
            <div class="img_binhluan"></div>
            <div class="content_comment">
                <textarea cols="70" rows="6" placeholder="<?=_GHIBINHTLUANODAY_LB?>"></textarea>
            </div>
            <input type="button" value="<?=_GUIBINHLUAN_LB?>" name="btsendcomment" class="btsendcomment" />
        </div>
    </div>
</div>