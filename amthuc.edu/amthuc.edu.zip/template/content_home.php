<script type="text/javascript">
			  Cufon.replace('.introduce li,.introduce h1', { fontFamily: 'UVNBayBuom' });
		  	</script>
        	<div class="introduce">
            	<h1><?=_GIOITHIEUNETSPACE_LB?></h1>
                <ul>               	
                    <?=_GIOITHIEUNETSPACE_CT_LB?>
                </ul>
            </div>
            <?php
				require_once("template/new.php");
				require_once("template/picture.php");
				require_once("template/video.php");
			?>