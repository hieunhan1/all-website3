<?php for($i=1;$i<=12;$i++) {?>
    <div class="wr_more_category">
        <div class="img_more_category">
            <a href="?language=vi&cm=<?=_CHITIET_LINK?>"><img src="upload/deded.jpg" alt="" /></a>
        </div>
        <div class="title_more_category">
            <h2><a href="?language=vi&cm=<?=_CHITIET_LINK?>">Chả giò hải sản ăn với mắm nêm thượng hạn</a></h2>
        </div>
        <div class="desc_more_category">
            <p>
                Chả giò mực là món ăn có vị thơm
    mặn ngọt, cay hòa trộn với nhau,
    hương vị thơm ngon, có cách trình
    bày rất đẹp mắt.
            </p>
        </div>
        <div class="bot_more_category">
            <a href="#" class="like">5<img src="images/red_heart.png" alt=""/></a>                    	
            <a href="?language=vi&cm=<?=_CHITIET_LINK?>" class="view_more"><?=_CHITIET_LB?></a>
        </div>
    </div>
<?php } ?>
	<div class="pagination_more_category">
        <a href="#">1</a>
        <a href="#">2</a>
        <a href="#">3</a>
        <a href="#">4</a>
        <a href="#">5</a>
        <a> ...</a>
        <a href="#"><?=_CUOI_LB?></a>
    </div>