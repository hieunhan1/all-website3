<div class="top_head">
    <div class="taskbar_top">
    	<script type="text/javascript">
			function SetCookie(cookieName,cookieValue,nDays) 
			{
				 var today = new Date();
				 var expire = new Date();
				 if (nDays==null || nDays==0) nDays=1;
				 expire.setTime(today.getTime() + 3600000*24*nDays);
				 document.cookie = cookieName+"="+escape(cookieValue)
								 + ";expires="+expire.toGMTString();
				window.location.reload();
			}
		</script>
        <ul>
            <li><a id="lang_vn"  onclick="SetCookie('language','vi',30)">VN</a> </li>    
            <li><a id="lang_eng" onclick="SetCookie('language','en',30)">EN</a></li>    
        </ul>
        
    </div>
    <div class="logo">
        <div  id="logo">
            <script src="js/lib/jquery-1.9.0.min.js" type="text/javascript"></script>
            <script src="js/jquery.index.js" type="text/javascript"></script>
        </div>
    </div>
    <div class="menu">
        <ul>
            <li><a href='?language=<?=$_COOKIE['language']?>'><?=_TRANGCHU_LB?></a></li>
            <li><a href="?language=<?=$_COOKIE['language']?>&cm=<?=_DOITAC_LINK?>" ><?=_DOITAC_LB?></a></li>
            <li><a href="?language=<?=$_COOKIE['language']?>&cm=<?=_DICHVU_LINK?>"><?=_DICHVU_LB?></a></li>
            <li><a href="?language=<?=$_COOKIE['language']?>&cm=<?=_TINTUC_LINK?>"><?=_TINTUC_LB?></a></li>
            <li><a href="?language=<?=$_COOKIE['language']?>&cm=<?=_LIENHE_LINK?>"><?=_LIENHE_LB?></a></li>
            <li><a href="?language=<?=$_COOKIE['language']?>&cm=<?=_EMAIL_LINK?>"><?=_EMAIL_LB?></a></li>
            <li><a href=""../forum/index.php" target="_blank"><?=_FORUM_LB?></a></li>
        </ul>
    </div>
</div>