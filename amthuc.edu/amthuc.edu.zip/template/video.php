<div class="video">
    <div class="head_video">
        <img alt="video" src="images/img_head_video.png" />
    </div>
    <div class="list_video">
        <div class="farm_video">
            <iframe width="280" height="235" src="//www.youtube.com/embed/UYyoDUeYJow" frameborder="0" allowfullscreen></iframe>
        </div>
        <div class="farm_video">
            <iframe width="280" height="235" src="//www.youtube.com/embed/vnPwze3XFRQ" frameborder="0" allowfullscreen></iframe>                   
        </div>
        <div class="farm_video">
        	<iframe width="280" height="235" src="//www.youtube.com/embed/HxjGq6e7K8s?list=PL51E1EF9B180F1356" frameborder="0" allowfullscreen></iframe>    
        </div>
    </div>
    <div style="clear:both"></div>
</div>