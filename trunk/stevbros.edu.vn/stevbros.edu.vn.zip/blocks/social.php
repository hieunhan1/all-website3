<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/vi_VN/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, "script", "facebook-jssdk"));</script>

<div style="width:auto; float:left" class="fb-like" data-href="http://www.facebook.com/pages/Stevbros-Training-Consultancy/111112242381308" data-width="140" data-layout="button_count"></div>
<div style="width:auto; height:17px; line-height:17px; float:left; margin:1px 10px 0 10px; padding:0 5px; font-size:11px; background-color:#ECEEF5; border:solid 1px #CAD4E7"><a style="color:#3B5998" href="#" onclick=\'window.open("https://www.facebook.com/sharer/sharer.php?u="+encodeURIComponent(location.href), "facebook-share-dialog", "width=626,height=436"); return false;\'>Chia sẻ lên facebook</a></div>