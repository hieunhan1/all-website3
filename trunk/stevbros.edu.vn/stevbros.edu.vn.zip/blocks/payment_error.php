<?php
$view_post .= $tc->navigator($row_menu_one['url'],$row_menu_one['name'],$row_menu_one['title'],'h3');
$view_post .= '
<div id="left"><div id="view_post">
	<h1>Thanh toán thất bại.</h1>
	<p style="line-height:22px; margin:10px 0"><strong>Kính gởi quý khách,</strong></p>
	<p style="line-height:22px; margin:10px 0">Cảm ơn quý khách đã quan tâm đến các khoá học thanh toán qua mạng của Stevbros.</p>
	<p style="line-height:22px; margin:10px 0">Chúng tôi rất tiếc thông báo giao dịch của quý khách không thành công tại thời điểm này.</p>
	<p style="line-height:22px; margin:10px 0">Nếu quý khách cần hổ trợ, vui lòng email về <a href="mailto:support@stevbros.com">support@stevbros.com</a>. Chúng tôi rất vui lòng được phục vụ quý khách.</p>
	<p style="line-height:22px; margin:10px 0">Trân trọng,<br />Stevbros Training & Consultancy.</p>
</div></div>';