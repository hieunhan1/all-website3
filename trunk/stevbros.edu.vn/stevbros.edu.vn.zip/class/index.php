<?php
header('Location: /'); exit;