<?php 
	class db{
		private $servername 	= 	"localhost";
		private $username 		= 	"stevbros_web";
		private $password 		= 	"stevbros_web123";
		private $dbname			=	"stevbros_web";
		
		function __construct(){
			$ketnoi	= mysql_connect($this->servername,$this->username,$this->password);
			mysql_select_db($this->dbname);
			mysql_query("set names 'utf8'");
		}//end function __construct()
	}//end class db
?>