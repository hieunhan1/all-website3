<?php
$max_results = 30;
define(DIR, '../../class/');
require_once DIR.'class.quantri.php';
$qt = new quantri();


$error_sql = "<p class='error'>Không truy vấn được.</p>";
$required = "<span style='color:red'>*</span>";
?>