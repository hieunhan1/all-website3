<div id="logo"><p>Trang quản trị website <strong></strong></p></div>
<div id="thongtin">
  <p> User: <strong><?=$user?></strong>    <a href="administrator.php?p=thongtin">Thông tin tài khoản</a> | <a href="<?php echo "administrator.php?p=thoat"?>">Logout</a></p>
</div>