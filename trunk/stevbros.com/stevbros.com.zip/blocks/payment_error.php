<?php
$view_post .= $tc->navigator($row_menu_one['url'],$row_menu_one['name'],$row_menu_one['title'],'h3');
$view_post .= '
<div id="left"><div id="view_post">
	<h1>Payment transaction failed</h1>
	<p style="line-height:22px; margin:10px 0"><strong>Dear Valued Customer,</strong></p>
	<p style="line-height:22px; margin:10px 0">Thank you for your interest in Stevbros\' training courses.</p>
	<p style="line-height:22px; margin:10px 0">We regret to inform you that your payment transaction is not successful now.</p>
	<p style="line-height:22px; margin:10px 0">Please feel free to contact us at <a href="mailto:support@stevbros.com">support@stevbros.com</a> if you need any support.</p>
	<p style="line-height:22px; margin:10px 0">Yours sincerely,<br />Stevbros Training & Consultancy.</p>
</div></div>';