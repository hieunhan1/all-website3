<?php
define('MERCHANT_ID', '30244');
define('MERCHANT_PASS', 'stevbrose###@2123');
define('RECEIVER','training@stevbros.com');
?>