<?
define(home_page,'home');
define(const_tin_khac, 'Other post');

define(const_thong_tin, 'Contact Information');
define(const_date_update, 'Update ');
define(const_txt_search, 'enter keywords..');

define(const_contact_name, 'Name');
define(const_contact_phone, 'Telephone');
define(const_contact_diachi, 'Address');
define(const_contact_message, 'Message');
define(const_contact_sent, 'SEND');