<?php
define(home_page,'trang-chu');
define(const_tin_khac, 'Bài viết khác');

define(const_thong_tin, 'Thông tin liên hệ');
define(const_date_update, 'Cập nhật ');
define(const_txt_search, 'Nhập từ khóa..');

define(const_contact_name, 'Họ &amp; tên');
define(const_contact_phone, 'Điện thoại');
define(const_contact_diachi, 'Địa chỉ');
define(const_contact_message, 'Nội dung');
define(const_contact_sent, 'GỬI ĐI');