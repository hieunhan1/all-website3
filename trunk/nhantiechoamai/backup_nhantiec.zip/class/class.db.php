<?php 
	class db{
		private $servername 	= 	"localhost";
		private $username 		= 	"nhantiec_user1";
		private $password 		= 	"nhantiec_database#123*";
		private $dbname			=	"nhantiec_database";
		
		function __construct(){
			$ketnoi	= mysql_connect($this->servername,$this->username,$this->password);
			mysql_select_db($this->dbname);
			mysql_query("set names 'utf8'");
		}//end function __construct()
	}//end class db
?>