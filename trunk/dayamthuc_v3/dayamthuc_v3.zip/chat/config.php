<?php
/* Thông tin kết nối Database */
define('CONS_HOST', 'localhost');
define('CONS_USER_DB', 'dayamthu_user3');
define('CONS_PASS_DB', 'dayamthu_amthuc_v3#123*');
define('CONS_DB_NAME', 'dayamthu_amthuc_v3');

define("CONS_WORK_SESSION", 1000);
