<?php
define('const_tin_khac', '其它信息');

define('const_date_update', '更新 ');
define('const_txt_search', '搜索..');

define('const_view_info', '详细');

define('const_cho_dakao','多高街市对面');

define('const_home_info', '厨师信息');
define('const_home_event', '活动');
define('const_home_notify', '通告');
define('const_home_video', '影片');
define('const_home_photos', '照片');

define('const_id_danhmuc_hinhanh', 5);

define('const_thong_tin', '通讯联络');
define('const_contact_name', '姓名');
define('const_contact_phone', '电话');
define('const_contact_email', '邮箱');
define('const_contact_diachi', '地址');
define('const_contact_message', '内容');
define('const_contact_sent', '寄发');

define('const_register_online', '直线登记');