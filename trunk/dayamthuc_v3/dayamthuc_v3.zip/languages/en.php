<?
define('const_tin_khac', 'Other post');

define('const_date_update', 'Update ');
define('const_txt_search', 'enter keywords..');

define('const_view_info', 'View more');

define('const_cho_dakao','Near Dakao market');

define('const_home_info', 'Update');
define('const_home_event', 'Events');
define('const_home_notify', 'Notification');
define('const_home_video', 'Videos');
define('const_home_photos', 'Photos');

define('const_id_danhmuc_hinhanh', 263);

define('const_thong_tin', 'Contact Information');
define('const_contact_name', 'Name');
define('const_contact_phone', 'Telephone');
define('const_contact_email', 'Email');
define('const_contact_diachi', 'Address');
define('const_contact_message', 'Message');
define('const_contact_sent', 'SEND CONTACT');

define('const_register_online', 'Apply now');