<?php
define('const_tin_khac', 'Bài viết khác');

define('const_date_update', 'Cập nhật ');
define('const_txt_search', 'Nhập từ khóa..');

define('const_view_info', 'Xem chi tiết');

define('const_cho_dakao','Đối diện Chợ Đakao');

define('const_home_info', 'Thông tin nấu ăn');
define('const_home_event', 'Sự kiện');
define('const_home_notify', 'Thông báo');
define('const_home_video', 'Videos');
define('const_home_photos', 'Hình ảnh');

define('const_id_danhmuc_hinhanh', 5);

define('const_thong_tin', 'Thông tin liên hệ');
define('const_contact_name', 'Họ &amp; tên');
define('const_contact_phone', 'Điện thoại');
define('const_contact_email', 'Email');
define('const_contact_diachi', 'Địa chỉ');
define('const_contact_message', 'Nội dung');
define('const_contact_sent', 'GỬI LIÊN HỆ');

define('const_register_online', 'Ghi danh trực tuyến');