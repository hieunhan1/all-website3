<?php
$navigator = '<div id="navigator"><a href="http://'.$domain.'/'.$lang.'/"><img src="images/home.jpg" alt="Hoang Ha Logistics" /></a> <span>&gt;&gt;</span> <a href="'.$lang.'/'.$row_menu_one['url'].'">'.$row_menu_one['name'].'</a></div>';
echo $navigator.'<div id="support"><h1>'.$row_menu_one['title'].'</h1><h2>'.$row_menu_one['metaDescription'].'</h2></div>';
?>
<table style="width:100%" cellpadding="0" cellspacing="0" id="network">
    <tbody>
    <tr class="vrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">GMT</span></td>
    <td style="background-color: #0096db; width: 37px;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Ha Noi</span></td>
    <td style="background-color: #0096db; width: 37px;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">HCMC</span></td>
    <td style="background-color: #0096db; width: 37px;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Brussels</span></td>
    <td style="background-color: #0096db; width: 37px;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Frankfurt</span></td>
    <td style="background-color: #0096db; width: 37px;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">HongKong</span></td>
    <td style="background-color: #0096db; width: 37px;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Houston</span></td>
    <td style="background-color: #0096db; width: 37px;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Rome</span></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="GMT">July 6, 2012<br /> 6:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Jakarta">July 6, 2012<br />13:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="HaNoi">July 6, 2012<br />13:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Brussels">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Frankfurt">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="HongKong">July 6, 2012<br />14:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Houston">July 6, 2012<br /> 1:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Rome">July 6, 2012<br /> 8:49:03 DST</span></td>
    </tr>
    <tr class="hrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Amsterdam</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Athens</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Atlanta</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Baghdad</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Bangkok</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Barcelona</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Beijing</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Beirut</span></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="Amsterdam">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Athens">July 6, 2012<br /> 9:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Atlanta">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Baghdad">July 6, 2012<br />10:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Bangkok">July 6, 2012<br />13:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Barcelona">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Beijing">July 6, 2012<br />14:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Beirut">July 6, 2012<br /> 9:49:03 DST</span></td>
    </tr>
    <tr class="hrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Berlin</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Boston</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Brisbane</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">BuenosAires</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Cairo</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Chicago</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Denver</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Detroit</span></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="Berlin">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Boston">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Brisbane">July 6, 2012<br />16:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="BuenosAires">July 6, 2012<br /> 3:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Cairo">July 6, 2012<br /> 9:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Chicago">July 6, 2012<br /> 1:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Denver">July 6, 2012<br /> 0:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Detroit">July 6, 2012<br /> 2:49:03 DST</span></td>
    </tr>
    <tr class="hrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Dubai</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Dublin</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Helsinki</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Indianapolis</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Istanbul</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Jerusalem</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Kamchatka</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Lisbon</span></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="Dubai">July 6, 2012<br />10:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Dublin">July 6, 2012<br /> 7:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Helsinki">July 6, 2012<br /> 9:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Indianapolis">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Istanbul">July 6, 2012<br /> 9:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Jerusalem">July 6, 2012<br /> 9:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Kamchatka">July 6, 2012<br />19:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Lisbon">July 6, 2012<br /> 7:49:03 DST</span></td>
    </tr>
    <tr class="hrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">London</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">LosAngeles</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Madrid</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Melbourne</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">MexicoCity</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Miami</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Minsk</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Montgomery</span></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="London">July 6, 2012<br /> 7:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="LosAngeles">July 5, 2012<br />23:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Madrid">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Melbourne">July 6, 2012<br />16:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="MexicoCity">July 6, 2012<br /> 1:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Miami">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Minsk">July 6, 2012<br /> 9:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Montgomery">July 6, 2012<br /> 1:49:03 DST</span></td>
    
    </tr>
    <tr class="hrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Montreal</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Moscow</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">NewOrleans</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">NewYork</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Paris</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Philadelphia</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Prague</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">RioDeJaneiro</span></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="Montreal">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Moscow">July 6, 2012<br />10:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="NewOrleans">July 6, 2012<br /> 1:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="NewYork">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Paris">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Philadelphia">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Prague">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="RioDeJaneiro">July 6, 2012<br /> 3:49:03</span></td>
    </tr>
    <tr class="hrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">SanFrancisco</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">SaoPaulo</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Seattle</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Seoul</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Shanghai</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Stockholm</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Sydney</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Tokyo</span></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="SanFrancisco">July 5, 2012<br />23:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="SaoPaulo">July 6, 2012<br /> 3:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Seattle">July 5, 2012<br />23:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Seoul">July 6, 2012<br />15:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Shanghai">July 6, 2012<br />14:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Stockholm">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Sydney">July 6, 2012<br />16:49:03</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Tokyo">July 6, 2012<br />15:49:03</span></td>
    </tr>
    <tr class="hrow">
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Vancouver</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Vienna</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">Vladivostok</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">WashingtonDC</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"><span style="color: #ffffff;">&nbsp;</span></td>
    <td style="background-color: #0096db;"></td>
    <td style="background-color: #0096db;"></td>
    <td style="background-color: #0096db;"></td>
    <td style="background-color: #0096db;"></td>
    <td style="background-color: #0096db;"></td>
    <td style="background-color: #0096db;"></td>
    </tr>
    <tr>
    <td style="background-color: #f2f2f2;"><span id="Vancouver">July 5, 2012<br />23:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Vienna">July 6, 2012<br /> 8:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="Vladivostok">July 6, 2012<br />17:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"><span><br data-mce-bogus="1" /></span></td>
    <td style="background-color: #f2f2f2;"><span id="WashingtonDC">July 6, 2012<br /> 2:49:03 DST</span></td>
    <td style="background-color: #f2f2f2;"></td>
    <td style="background-color: #f2f2f2;"></td>
    <td style="background-color: #f2f2f2;"></td>
    <td style="background-color: #f2f2f2;"></td>
    <td style="background-color: #f2f2f2;"></td>
    <td style="background-color: #f2f2f2;"></td>
    <td style="background-color: #f2f2f2;"></td>
    <td style="background-color: #f2f2f2;"></td>
    </tr>
    </tbody>
</table>
<script language="JavaScript">
	<!--
	function worldClock(zone, region){
	var dst = 0
	var time = new Date()
	var gmtMS = time.getTime() + (time.getTimezoneOffset() * 60000)
	var gmtTime = new Date(gmtMS)
	var day = gmtTime.getDate()
	var month = gmtTime.getMonth()
	var year = gmtTime.getYear()
	if(year < 1000){
	year += 1900
	}
	var monthArray = new Array("January", "February", "March", "April", "May", "June", "July", "August", 
	"September", "October", "November", "December")
	
	var monthDays = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
	if (year%4 == 0){
	monthDays = new Array("31", "29", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
	}
	if(year%100 == 0 && year%400 != 0){
	monthDays = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
	}
	
	var hr = gmtTime.getHours() + zone
	var min = gmtTime.getMinutes()
	var sec = gmtTime.getSeconds()
	
	if (hr >= 24){
	hr = hr-24
	day -= -1
	}
	if (hr < 0){
	hr -= -24
	day -= 1
	}
	if (hr < 10){
	hr = " " + hr
	}
	if (min < 10){
	min = "0" + min
	}
	if (sec < 10){
	sec = "0" + sec
	}
	if (day <= 0){
	if (month == 0){
	month = 11
	year -= 1
	}
	else{
	month = month -1
	}
	day = monthDays[month]
	}
	if(day > monthDays[month]){
	day = 1
	if(month == 11){
	month = 0
	year -= -1
	}
	else{
	month -= -1
	}
	}
	if (region == "NAmerica"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(3)
	startDST.setHours(2)
	startDST.setDate(1)
	var dayDST = startDST.getDay()
	if (dayDST != 0){
	startDST.setDate(8-dayDST)
	}
	else{
	startDST.setDate(1)
	}
	endDST.setMonth(9)
	endDST.setHours(1)
	endDST.setDate(31)
	dayDST = endDST.getDay()
	endDST.setDate(31-dayDST)
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST && currentTime < endDST){
	dst = 1
	}
	}
	if (region == "Europe"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(2)
	startDST.setHours(1)
	startDST.setDate(31)
	var dayDST = startDST.getDay()
	startDST.setDate(31-dayDST)
	endDST.setMonth(9)
	endDST.setHours(0)
	endDST.setDate(31)
	dayDST = endDST.getDay()
	endDST.setDate(31-dayDST)
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST && currentTime < endDST){
	dst = 1
	}
	}
	
	if (region == "SAmerica"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(9)
	startDST.setHours(0)
	startDST.setDate(1)
	var dayDST = startDST.getDay()
	if (dayDST != 0){
	startDST.setDate(22-dayDST)
	}
	else{
	startDST.setDate(15)
	}
	endDST.setMonth(1)
	endDST.setHours(11)
	endDST.setDate(1)
	dayDST = endDST.getDay()
	if (dayDST != 0){
	endDST.setDate(21-dayDST)
	}
	else{
	endDST.setDate(14)
	}
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST || currentTime < endDST){
	dst = 1
	}
	}
	if (region == "Cairo"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(3)
	startDST.setHours(0)
	startDST.setDate(30)
	var dayDST = startDST.getDay()
	if (dayDST < 5){
	startDST.setDate(28-dayDST)
	}
	else {
	startDST.setDate(35-dayDST)
	}
	endDST.setMonth(8)
	endDST.setHours(11)
	endDST.setDate(30)
	dayDST = endDST.getDay()
	if (dayDST < 4){
	endDST.setDate(27-dayDST)
	}
	else{
	endDST.setDate(34-dayDST)
	}
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST && currentTime < endDST){
	dst = 1
	}
	}
	if (region == "Israel"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(3)
	startDST.setHours(2)
	startDST.setDate(1)
	endDST.setMonth(8)
	endDST.setHours(2)
	endDST.setDate(25)
	dayDST = endDST.getDay()
	if (dayDST != 0){
	endDST.setDate(32-dayDST)
	}
	else{
	endDST.setDate(1)
	endDST.setMonth(9)
	}
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST && currentTime < endDST){
	dst = 1
	}
	}
	if (region == "Beirut"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(2)
	startDST.setHours(0)
	startDST.setDate(31)
	var dayDST = startDST.getDay()
	startDST.setDate(31-dayDST)
	endDST.setMonth(9)
	endDST.setHours(11)
	endDST.setDate(31)
	dayDST = endDST.getDay()
	endDST.setDate(30-dayDST)
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST && currentTime < endDST){
	dst = 1
	}
	}
	if (region == "Baghdad"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(3)
	startDST.setHours(3)
	startDST.setDate(1)
	endDST.setMonth(9)
	endDST.setHours(3)
	endDST.setDate(1)
	dayDST = endDST.getDay()
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST && currentTime < endDST){
	dst = 1
	}
	}
	if (region == "Australia"){
	var startDST = new Date()
	var endDST = new Date()
	startDST.setMonth(9)
	startDST.setHours(2)
	startDST.setDate(31)
	var dayDST = startDST.getDay()
	startDST.setDate(31-dayDST)
	endDST.setMonth(2)
	endDST.setHours(2)
	endDST.setDate(31)
	dayDST = endDST.getDay()
	endDST.setDate(31-dayDST)
	var currentTime = new Date()
	currentTime.setMonth(month)
	currentTime.setYear(year)
	currentTime.setDate(day)
	currentTime.setHours(hr)
	if(currentTime >= startDST || currentTime < endDST){
	dst = 1
	}
	}
	
	
	if (dst == 1){
	hr -= -1
	if (hr >= 24){
	hr = hr-24
	day -= -1
	}
	if (hr < 10){
	hr = " " + hr
	}
	if(day > monthDays[month]){
	day = 1
	if(month == 11){
	month = 0
	year -= -1
	}
	else{
	month -= -1
	}
	}
	return monthArray[month] + " " + day + ", " + year + "<br />" + hr + ":" + min + ":" + sec + " DST"
	}
	else{
	return monthArray[month] + " " + day + ", " + year + "<br />" + hr + ":" + min + ":" + sec
	}
	}
	
	function worldClockZone(){
	document.getElementById("GMT").innerHTML = worldClock(0, "Greenwich")
	document.getElementById("Jakarta").innerHTML = worldClock(7, "Jakarta")
	document.getElementById("HaNoi").innerHTML = worldClock(7, "HaNoi")
	document.getElementById("Brussels").innerHTML = worldClock(1, "Europe")
	document.getElementById("Frankfurt").innerHTML = worldClock(1, "Europe")
	document.getElementById("HongKong").innerHTML = worldClock(8, "HongKong")
	document.getElementById("Houston").innerHTML = worldClock(-6, "NAmerica")
	document.getElementById("Rome").innerHTML = worldClock(1, "Europe")
	document.getElementById("Amsterdam").innerHTML = worldClock(1, "Europe")
	document.getElementById("Athens").innerHTML = worldClock(2, "Europe")
	document.getElementById("Atlanta").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Baghdad").innerHTML = worldClock(3, "Baghdad")
	document.getElementById("Bangkok").innerHTML = worldClock(7, "Bangkok")
	document.getElementById("Barcelona").innerHTML = worldClock(1, "Europe")
	document.getElementById("Beijing").innerHTML = worldClock(8, "Beijing")
	document.getElementById("Beirut").innerHTML = worldClock(2, "Beirut")
	document.getElementById("Berlin").innerHTML = worldClock(1, "Europe")
	document.getElementById("Boston").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Brisbane").innerHTML = worldClock(10, "Brisbane")
	document.getElementById("BuenosAires").innerHTML = worldClock(-3, "BuenosAires")
	document.getElementById("Cairo").innerHTML = worldClock(2, "Cairo")
	document.getElementById("Chicago").innerHTML = worldClock(-6, "NAmerica")
	document.getElementById("Denver").innerHTML = worldClock(-7, "NAmerica")
	document.getElementById("Detroit").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Dubai").innerHTML = worldClock(4, "Dubai")
	document.getElementById("Dublin").innerHTML = worldClock(0, "Europe")
	document.getElementById("Helsinki").innerHTML = worldClock(2, "Europe")
	document.getElementById("Indianapolis").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Istanbul").innerHTML = worldClock(2, "Europe")
	document.getElementById("Jerusalem").innerHTML = worldClock(2, "Israel")
	document.getElementById("Kamchatka").innerHTML = worldClock(12, "Europe")
	document.getElementById("Lisbon").innerHTML = worldClock(0, "Europe")
	document.getElementById("London").innerHTML = worldClock(0, "Europe")
	document.getElementById("LosAngeles").innerHTML = worldClock(-8, "NAmerica")
	document.getElementById("Madrid").innerHTML = worldClock(1, "Europe")
	document.getElementById("Melbourne").innerHTML = worldClock(10, "Australia")
	document.getElementById("MexicoCity").innerHTML = worldClock(-6, "NAmerica")
	document.getElementById("Miami").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Minsk").innerHTML = worldClock(2, "Europe")
	document.getElementById("Montgomery").innerHTML = worldClock(-6, "NAmerica")
	document.getElementById("Montreal").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Moscow").innerHTML = worldClock(3, "Europe")
	document.getElementById("NewOrleans").innerHTML = worldClock(-6, "NAmerica")
	document.getElementById("NewYork").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Paris").innerHTML = worldClock(1, "Europe")
	document.getElementById("Philadelphia").innerHTML = worldClock(-5, "NAmerica")
	document.getElementById("Prague").innerHTML = worldClock(1, "Europe")
	document.getElementById("RioDeJaneiro").innerHTML = worldClock(-3, "SAmerica")
	document.getElementById("SanFrancisco").innerHTML = worldClock(-8, "NAmerica")
	document.getElementById("SaoPaulo").innerHTML = worldClock(-3, "SAmerica")
	document.getElementById("Seattle").innerHTML = worldClock(-8, "NAmerica")
	document.getElementById("Seoul").innerHTML = worldClock(9, "Seoul")
	document.getElementById("Shanghai").innerHTML = worldClock(8, "Shanghai")
	document.getElementById("Stockholm").innerHTML = worldClock(1, "Europe")
	document.getElementById("Sydney").innerHTML = worldClock(10, "Australia")
	document.getElementById("Tokyo").innerHTML = worldClock(9, "Tokyo")
	document.getElementById("Vancouver").innerHTML = worldClock(-8, "NAmerica")
	document.getElementById("Vienna").innerHTML = worldClock(1, "Europe")
	document.getElementById("Vladivostok").innerHTML = worldClock(10, "Europe")
	document.getElementById("WashingtonDC").innerHTML = worldClock(-5, "NAmerica")
	setTimeout("worldClockZone()", 1000)
	}
	window.onload=worldClockZone;
	//-->
</script>