<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Không tìm thấy trang</title>
</head>

<body>
	<p style="text-align:center; color:#F00; font-size:150%; font-weight:bold; margin-top:50px">SISP không tìm thấy trang bạn cần tìm.</p>
</body>
</html>