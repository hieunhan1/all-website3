<?php
define('const_xem_chi_tiet','Xem chi tiết');
define('const_xem_tat_ca','xem tất cả');
define('const_tin_khac', 'Bài viết khác');
define('const_partner', 'Đối tác của SIUP');
define('const_txt_search', 'Tìm kiếm nội dung');

define('const_thongtin_duan','Thông tin chung dự án');
define('const_duan_cungloai','Dự án cùng loại');

define('const_thong_tin', 'Mọi thắc mắc, đóng góp ý kiên vui lòng gửi cho chúng tôi bằng cách điền đầy đủ thông tin vào form bên dưới. Chúng tôi sẽ trả lời trong thời gian sớm nhất.');
define('const_contact_name', 'Họ tên');
define('const_contact_phone', 'Điện thoại');
define('const_contact_diachi', 'Địa chỉ');
define('const_contact_message', 'Nội dung');
define('const_contact_sent', 'GỬI LIÊN HỆ');
define('const_contact_success', 'Gửi liên hệ thành công.');
define('const_contact_error', 'Lỗi. Vui lòng ấn F5 thử lại.');