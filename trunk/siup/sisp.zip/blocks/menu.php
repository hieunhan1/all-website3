<?php
$view_menu = '<div id="menu"><ul id="nav">';
$menu = $tc->menu(0,2,$lang);
while($row = mysql_fetch_array($menu)){
	if($menu_root != $row['id']){
		$view_menu .= '<li><a href="'.$row['url'].'"  title="'.$row['title'].'">'.$row['name'].'</a>';
		$view_menu .= $tc->getSubmenu($row['id'],2);
		$view_menu .= '</li>';
	}else{
		$view_menu .= '<li><a href="'.$row['url'].'"  title="'.$row['title'].'" style="color:#e2e2e2">'.$row['name'].'</a>';
		$view_menu .= $tc->getSubmenu($row['id'],2);
		$view_menu .= '</li>';
	}
}
$view_menu .= '</ul></div>';
echo $view_menu;