<?php 
	class db{
		private $servername 	= 	"localhost";
		private $username 		= 	"mimosaar_user";
		private $password 		= 	"mimosaar_data#123*";
		private $dbname			=	"mimosaar_data";
		
		function __construct(){
			$ketnoi	= mysql_connect($this->servername,$this->username,$this->password);
			mysql_select_db($this->dbname);
			mysql_query("set names 'utf8'");
		}//end function __construct()
	}//end class db
?>